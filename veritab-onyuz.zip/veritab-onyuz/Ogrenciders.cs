﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace veritab_onyuz
{
    public partial class Ogrenciders : Form
    {
        public Ogrenciders()
        {
            InitializeComponent();
        }

        private void btn_listele_Click(object sender, EventArgs e)
        {

            if(txtbx_ogrno.Text.ToString().Equals(""))
            {

                MessageBox.Show("Ogrenci numarası zorunludur");
                return ;
            }

            lst_ogrders.Items.Clear();

            lst_ogrders.Columns.Clear();


            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();



            string sql =
           "select a.ogrenci_no,ogr.ad,ogr.soyad,d.ders_kodu,d.ders_adi ,teach.ogretmen_no,teach.ad,teach.soyad,to_char(a.tarih, 'DD.MM.YYYY') as tarih " +
           "from ogrenci_alinan_dersler a join dersler d on d.ders_kodu = a.ders_kodu " +
                                         "join ogrenciler ogr on a.ogrenci_no = ogr.ogrenci_no " +
                                        "join ogretmenler teach on teach.ogretmen_no = a.ogretmen_no " +
                         "where a.ogrenci_no = " + txtbx_ogrno.Text.ToString();
                          



           

            var cmd = new NpgsqlCommand(sql, connection);

            NpgsqlDataReader dr = cmd.ExecuteReader();

            lst_ogrders.View = View.Details;

            lst_ogrders.Columns.Add("Öğrenci No");
            lst_ogrders.Columns.Add("Öğrenci Adı");
            lst_ogrders.Columns.Add("Öğrenci Soyadı");
            lst_ogrders.Columns.Add("Ders Kodu");
            lst_ogrders.Columns.Add("Ders Adı");
            lst_ogrders.Columns.Add("Öğretmen No");
            lst_ogrders.Columns.Add("Öğretmen Adı");
            lst_ogrders.Columns.Add("Öğretmen Soyadı");
            lst_ogrders.Columns.Add("Tarih");


            lst_ogrders.Columns[0].Width = 100;
            lst_ogrders.Columns[1].Width = 100;
            lst_ogrders.Columns[2].Width = 100;
            lst_ogrders.Columns[3].Width = 100;
            lst_ogrders.Columns[4].Width = 100;
            lst_ogrders.Columns[5].Width = 100;
            lst_ogrders.Columns[6].Width = 100;
            lst_ogrders.Columns[7].Width = 100;
            lst_ogrders.Columns[8].Width = 100;


            while (dr.Read())
            {
                ///Console.WriteLine(dr[0]+"-"+dr[1]+"-"+dr[2]+"-"+dr[3]);
                lst_ogrders.Items.Add(
                    new ListViewItem(
                       new string[] { dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString(), dr[8].ToString() }
                        )
                    );


            }


            connection.Close();







        }
    }
}
