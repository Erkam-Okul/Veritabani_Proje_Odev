﻿namespace veritab_onyuz
{
    partial class ogrenci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_kaydet = new System.Windows.Forms.Button();
            this.txtbx_ogrno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ogr = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbx_ogradi = new System.Windows.Forms.TextBox();
            this.txtbx_ogrsoyadi = new System.Windows.Forms.TextBox();
            this.btn_listele = new System.Windows.Forms.Button();
            this.lst_ogrenci = new System.Windows.Forms.ListView();
            this.btn_guncelle = new System.Windows.Forms.Button();
            this.btn_sil = new System.Windows.Forms.Button();
            this.cmb_il = new System.Windows.Forms.ComboBox();
            this.txtbx_araogrno = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbx_araograd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtbx_araogrsoyad = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_kaydet
            // 
            this.btn_kaydet.Location = new System.Drawing.Point(182, 571);
            this.btn_kaydet.Name = "btn_kaydet";
            this.btn_kaydet.Size = new System.Drawing.Size(160, 66);
            this.btn_kaydet.TabIndex = 0;
            this.btn_kaydet.Text = "kaydet";
            this.btn_kaydet.UseVisualStyleBackColor = true;
            this.btn_kaydet.Click += new System.EventHandler(this.btn_kaydet_Click);
            // 
            // txtbx_ogrno
            // 
            this.txtbx_ogrno.Enabled = false;
            this.txtbx_ogrno.Location = new System.Drawing.Point(139, 425);
            this.txtbx_ogrno.Name = "txtbx_ogrno";
            this.txtbx_ogrno.Size = new System.Drawing.Size(203, 22);
            this.txtbx_ogrno.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 425);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "ogrenci no";
            // 
            // ogr
            // 
            this.ogr.AutoSize = true;
            this.ogr.Location = new System.Drawing.Point(27, 481);
            this.ogr.Name = "ogr";
            this.ogr.Size = new System.Drawing.Size(78, 17);
            this.ogr.TabIndex = 3;
            this.ogr.Text = "ogrenci adı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 531);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "ogrenci soyadı";
            // 
            // txtbx_ogradi
            // 
            this.txtbx_ogradi.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbx_ogradi.Location = new System.Drawing.Point(139, 475);
            this.txtbx_ogradi.Name = "txtbx_ogradi";
            this.txtbx_ogradi.Size = new System.Drawing.Size(203, 22);
            this.txtbx_ogradi.TabIndex = 5;
            // 
            // txtbx_ogrsoyadi
            // 
            this.txtbx_ogrsoyadi.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbx_ogrsoyadi.Location = new System.Drawing.Point(139, 525);
            this.txtbx_ogrsoyadi.Name = "txtbx_ogrsoyadi";
            this.txtbx_ogrsoyadi.Size = new System.Drawing.Size(203, 22);
            this.txtbx_ogrsoyadi.TabIndex = 6;
            // 
            // btn_listele
            // 
            this.btn_listele.Location = new System.Drawing.Point(315, 133);
            this.btn_listele.Name = "btn_listele";
            this.btn_listele.Size = new System.Drawing.Size(423, 58);
            this.btn_listele.TabIndex = 7;
            this.btn_listele.Text = "listele";
            this.btn_listele.UseVisualStyleBackColor = true;
            this.btn_listele.Click += new System.EventHandler(this.btn_listele_Click);
            // 
            // lst_ogrenci
            // 
            this.lst_ogrenci.HideSelection = false;
            this.lst_ogrenci.Location = new System.Drawing.Point(12, 197);
            this.lst_ogrenci.MultiSelect = false;
            this.lst_ogrenci.Name = "lst_ogrenci";
            this.lst_ogrenci.Size = new System.Drawing.Size(1015, 195);
            this.lst_ogrenci.TabIndex = 8;
            this.lst_ogrenci.UseCompatibleStateImageBehavior = false;
            this.lst_ogrenci.SelectedIndexChanged += new System.EventHandler(this.lst_ogrenci_SelectedIndexChanged);
            // 
            // btn_guncelle
            // 
            this.btn_guncelle.Enabled = false;
            this.btn_guncelle.Location = new System.Drawing.Point(435, 571);
            this.btn_guncelle.Name = "btn_guncelle";
            this.btn_guncelle.Size = new System.Drawing.Size(162, 66);
            this.btn_guncelle.TabIndex = 9;
            this.btn_guncelle.Text = "guncelle";
            this.btn_guncelle.UseVisualStyleBackColor = true;
            this.btn_guncelle.Click += new System.EventHandler(this.btn_guncelle_Click);
            // 
            // btn_sil
            // 
            this.btn_sil.Enabled = false;
            this.btn_sil.Location = new System.Drawing.Point(675, 571);
            this.btn_sil.Name = "btn_sil";
            this.btn_sil.Size = new System.Drawing.Size(163, 66);
            this.btn_sil.TabIndex = 10;
            this.btn_sil.Text = "sil";
            this.btn_sil.UseVisualStyleBackColor = true;
            this.btn_sil.Click += new System.EventHandler(this.btn_sil_Click);
            // 
            // cmb_il
            // 
            this.cmb_il.FormattingEnabled = true;
            this.cmb_il.Location = new System.Drawing.Point(433, 423);
            this.cmb_il.Name = "cmb_il";
            this.cmb_il.Size = new System.Drawing.Size(189, 24);
            this.cmb_il.TabIndex = 11;
            // 
            // txtbx_araogrno
            // 
            this.txtbx_araogrno.Location = new System.Drawing.Point(139, 53);
            this.txtbx_araogrno.Name = "txtbx_araogrno";
            this.txtbx_araogrno.Size = new System.Drawing.Size(179, 22);
            this.txtbx_araogrno.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "ogrenci no";
            // 
            // txtbx_araograd
            // 
            this.txtbx_araograd.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbx_araograd.Location = new System.Drawing.Point(485, 52);
            this.txtbx_araograd.Name = "txtbx_araograd";
            this.txtbx_araograd.Size = new System.Drawing.Size(160, 22);
            this.txtbx_araograd.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(396, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 17);
            this.label4.TabIndex = 15;
            this.label4.Text = "ogrenci ad";
            // 
            // txtbx_araogrsoyad
            // 
            this.txtbx_araogrsoyad.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbx_araogrsoyad.Location = new System.Drawing.Point(860, 52);
            this.txtbx_araogrsoyad.Name = "txtbx_araogrsoyad";
            this.txtbx_araogrsoyad.Size = new System.Drawing.Size(156, 22);
            this.txtbx_araogrsoyad.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(741, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 17);
            this.label5.TabIndex = 17;
            this.label5.Text = "ogrenci soyad";
            // 
            // ogrenci
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 649);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtbx_araogrsoyad);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtbx_araograd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtbx_araogrno);
            this.Controls.Add(this.cmb_il);
            this.Controls.Add(this.btn_sil);
            this.Controls.Add(this.btn_guncelle);
            this.Controls.Add(this.lst_ogrenci);
            this.Controls.Add(this.btn_listele);
            this.Controls.Add(this.txtbx_ogrsoyadi);
            this.Controls.Add(this.txtbx_ogradi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ogr);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbx_ogrno);
            this.Controls.Add(this.btn_kaydet);
            this.Name = "ogrenci";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.ogrenci_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_kaydet;
        private System.Windows.Forms.TextBox txtbx_ogrno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ogr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbx_ogradi;
        private System.Windows.Forms.TextBox txtbx_ogrsoyadi;
        private System.Windows.Forms.Button btn_listele;
        private System.Windows.Forms.ListView lst_ogrenci;
        private System.Windows.Forms.Button btn_guncelle;
        private System.Windows.Forms.Button btn_sil;
        private System.Windows.Forms.ComboBox cmb_il;
        private System.Windows.Forms.TextBox txtbx_araogrno;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbx_araograd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbx_araogrsoyad;
        private System.Windows.Forms.Label label5;
    }
}