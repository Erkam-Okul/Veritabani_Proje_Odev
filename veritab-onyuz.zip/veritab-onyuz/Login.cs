﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace veritab_onyuz
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_giris_Click(object sender, EventArgs e)
        {

            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            var cmd = new NpgsqlCommand("select * from kullanicilar where kullanici_kodu='"+txtbx_kulkod.Text.ToString()+ "' and sifre='"+txtbx_sifre.Text.ToString()+"'"   , connection);

            NpgsqlDataReader dr = cmd.ExecuteReader();

            Boolean sifreDogru = false;
            while (dr.Read())
            {
                sifreDogru = true;
            }
            connection.Close();

            connection.Open();
            if (sifreDogru)
            {
                var cmdLoginInsert = new NpgsqlCommand(" insert into kullanici_login (kullanici_kodu,basarilimi,zaman) values ('"+ txtbx_kulkod.Text.ToString()+"','E',now()) ", connection);
                int sonuc=cmdLoginInsert.ExecuteNonQuery();


                Menu menu = new Menu(txtbx_kulkod.Text.ToString());
                menu.Show();
                this.Hide();
            } else
            {
                MessageBox.Show("Kullanıcı Kodu veya Şifre Yanlış");

                var cmdLoginInsert = new NpgsqlCommand(" insert into kullanici_login (kullanici_kodu,basarilimi,zaman) values ('" + txtbx_kulkod.Text.ToString() + "','H',now()) ", connection);
                int sonuc = cmdLoginInsert.ExecuteNonQuery();
            }

            connection.Close();


        }
    }
}
