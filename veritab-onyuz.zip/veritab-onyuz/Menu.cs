﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace veritab_onyuz
{
    public partial class Menu : Form
    {
        private string kullanici_kodu;

        public Menu()
        {
            InitializeComponent();
        }

        public Menu(string p_kullanici_kodu)
        {
            this.kullanici_kodu = p_kullanici_kodu;
            InitializeComponent();
        }

        private void btn_menuteach_Click(object sender, EventArgs e)
        {
            Ogretmen ogretmenekrani = new Ogretmen();
            ogretmenekrani.Show();


            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();
            var cmdIslemInsert = new NpgsqlCommand(" insert into kullanici_islem (kullanici_kodu,islem,zaman) values ('" + this.kullanici_kodu + "','OGRETMEN_EKRAN',now()) ", connection);
            int sonuc = cmdIslemInsert.ExecuteNonQuery();
            connection.Close();
        }

        private void btn_menuogr_Click(object sender, EventArgs e)
        {
            ogrenci ogrenciekrani = new ogrenci();
            ogrenciekrani.Show();


            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();
            var cmdIslemInsert = new NpgsqlCommand(" insert into kullanici_islem (kullanici_kodu,islem,zaman) values ('" + this.kullanici_kodu + "','OGRENCI_EKRAN',now()) ", connection);
            int sonuc = cmdIslemInsert.ExecuteNonQuery();
            connection.Close();
        }

        private void btn_ogrdersler_Click(object sender, EventArgs e)
        {
            Ogrenciders ogrencidersekrani = new Ogrenciders();
            ogrencidersekrani.Show();


            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();
            var cmdIslemInsert = new NpgsqlCommand(" insert into kullanici_islem (kullanici_kodu,islem,zaman) values ('" + this.kullanici_kodu + "','OGRDERS_EKRAN',now()) ", connection);
            int sonuc = cmdIslemInsert.ExecuteNonQuery();
            connection.Close();
        }

    }
}
