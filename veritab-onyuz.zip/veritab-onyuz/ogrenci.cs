﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace veritab_onyuz
{
    public partial class ogrenci : Form
    {
        public ogrenci()
        {
            InitializeComponent();
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {

            if (!kayitKontrol())
            {
                return;
            };

            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            using (var cmd = new NpgsqlCommand("ekle_ogrenci", connection))

            {
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.AddWithValue("p_ogrenci_no", Int32.Parse(txtbx_ogrno.Text));
                cmd.Parameters.AddWithValue("p_ogrenci_ad",txtbx_ogradi.Text);
                cmd.Parameters.AddWithValue("p_ogrenci_soyad", txtbx_ogrsoyadi.Text);

                //string secilenIlKoduveAdi = cmb_il.SelectedItem.ToString();
                string[] ilStrArr = cmb_il.SelectedItem.ToString().Split('-');

                cmd.Parameters.AddWithValue("p_ilkod", ilStrArr[0]);

                using (var reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("vt fonk cagrildi.....");
                }
            }

            connection.Close();

            MessageBox.Show("Ogrenci Kaydedildi");
    
        }

        private Boolean kayitKontrol()
        {
            if (txtbx_ogradi.Text.ToString().Equals(""))
            {
                MessageBox.Show("Öğrenci Adı Zorunludur");
                return false;
            }
            if (txtbx_ogrsoyadi.Text.ToString().Equals(""))
            {
                MessageBox.Show("Öğrenci Soyadı Zorunludur");
                return false;
            }

            if (cmb_il.SelectedItem==null)
            {
                MessageBox.Show("İl Seçiniz");
                return false;
            }

            return true;
        }

        private void btn_listele_Click(object sender, EventArgs e)
        {
            lst_ogrenci.Items.Clear();

            lst_ogrenci.Columns.Clear();

            

            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            string sql = " select o.ogrenci_no,o.ad,o.soyad,o.il_kod,i.il_ismi,o.adres " +
                          "   from ogrenciler o JOIN iller i ON o.il_kod = i.ilkod" +
                          " where 1=1 ";

            if (!txtbx_araogrno.Text.ToString().Equals(""))
            {
                sql = sql + " and o.ogrenci_no=" + txtbx_araogrno.Text.ToString();
            }


            if (!txtbx_araograd.Text.ToString().Equals(""))
            {
                sql = sql + " and o.ad='" + txtbx_araograd.Text.ToString() + "'";
            }

            if (!txtbx_araogrsoyad.Text.ToString().Equals(""))
            {
                sql = sql + " and o.soyad='" + txtbx_araogrsoyad.Text.ToString() + "'";
            }


            var cmd = new NpgsqlCommand(sql, connection);



            NpgsqlDataReader dr = cmd.ExecuteReader();

            lst_ogrenci.View = View.Details;

            lst_ogrenci.Columns.Add("Öğrenci No");
            lst_ogrenci.Columns.Add("Adı");
            lst_ogrenci.Columns.Add("Soyadı");
            lst_ogrenci.Columns.Add("İlkod");
            lst_ogrenci.Columns.Add("İl Adı");
            lst_ogrenci.Columns.Add("Adres");

            while (dr.Read())
            {
                ///Console.WriteLine(dr[0]+"-"+dr[1]+"-"+dr[2]+"-"+dr[3]);
                lst_ogrenci.Items.Add(
                    new ListViewItem(
                       new string[] { dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString()}
                        )
                    );


            }


            connection.Close();



        }

        private void lst_ogrenci_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lst_ogrenci.SelectedIndices.Count <= 0)
            {
                return;
            }
            btn_guncelle.Enabled = true;
            btn_sil.Enabled = true;



            //string curItem = lst_ogrenci.SelectedItems[0].Text;//.SelectedItems.ToString();
            //Console.WriteLine("secilen:"+ curItem);

            var item = lst_ogrenci.SelectedItems[0];

            txtbx_ogrno.Text = item.SubItems[0].Text;
            txtbx_ogradi.Text = item.SubItems[1].Text;
            txtbx_ogrsoyadi.Text = item.SubItems[2].Text;
            cmb_il.SelectedIndex = cmb_il.FindString(item.SubItems[3].Text);

        }

        private void btn_guncelle_Click(object sender, EventArgs e)
        {
            if (!kayitKontrol())
            {
                return;
            };

            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            using (var cmd = new NpgsqlCommand("guncelle_ogrenci", connection))

            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_ogrenci_no", Int32.Parse(txtbx_ogrno.Text));
                cmd.Parameters.AddWithValue("p_ogrenci_ad", txtbx_ogradi.Text);
                cmd.Parameters.AddWithValue("p_ogrenci_soyad", txtbx_ogrsoyadi.Text);
                string[] ilStrArr = cmb_il.SelectedItem.ToString().Split('-');
                cmd.Parameters.AddWithValue("p_ilkod", ilStrArr[0]);

                cmd.Parameters.AddWithValue("p_adres", "");

                using (var reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("vt fonk cagrildi.....");
                }
            }

            connection.Close();

            MessageBox.Show("Ogrenci güncellendi");

            btn_listele_Click(sender, e);

        }

        private void btn_sil_Click(object sender, EventArgs e)
        {
            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            using (var cmd = new NpgsqlCommand("delete_ogrenci", connection))

            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_ogrenci_no", Int32.Parse(txtbx_ogrno.Text));
               

                using (var reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("vt fonk cagrildi.....");
                }
            }

            connection.Close();

            MessageBox.Show("Ogrenci silindi");

            btn_listele_Click(sender, e);



        }

        private void ogrenci_Load(object sender, EventArgs e)
        {
           

            cmb_il.Items.Clear();
            //lst_ogrenci.Columns.Clear();


            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            var cmd = new NpgsqlCommand("select ilkod,il_ismi from iller", connection);
            NpgsqlDataReader dr = cmd.ExecuteReader();

            //lst_ogrenci.View = View.Details;
            //lst_ogrenci.Columns.Add("Öğrenci No");

            while (dr.Read())
            {
                cmb_il.Items.Add(dr[0].ToString() + "-" + dr[1].ToString());
            }


            connection.Close();


        }
    }
}
