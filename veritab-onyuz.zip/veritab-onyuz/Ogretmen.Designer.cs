﻿namespace veritab_onyuz
{
    partial class Ogretmen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_listeleteach = new System.Windows.Forms.Button();
            this.lstbx_ogretmen = new System.Windows.Forms.ListView();
            this.btn_ekleteach = new System.Windows.Forms.Button();
            this.btn_silteach = new System.Windows.Forms.Button();
            this.btn_guncelleteach = new System.Windows.Forms.Button();
            this.txtbx_noteach = new System.Windows.Forms.TextBox();
            this.txtbx_adteach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbx_soyadteach = new System.Windows.Forms.TextBox();
            this.cmb_bolum = new System.Windows.Forms.ComboBox();
            this.txtbx_araogrno = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtbx_araograd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbx_araogrsoyad = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_listeleteach
            // 
            this.btn_listeleteach.Location = new System.Drawing.Point(268, 102);
            this.btn_listeleteach.Name = "btn_listeleteach";
            this.btn_listeleteach.Size = new System.Drawing.Size(314, 47);
            this.btn_listeleteach.TabIndex = 0;
            this.btn_listeleteach.Text = "listele";
            this.btn_listeleteach.UseVisualStyleBackColor = true;
            this.btn_listeleteach.Click += new System.EventHandler(this.btn_listeleteach_Click);
            // 
            // lstbx_ogretmen
            // 
            this.lstbx_ogretmen.HideSelection = false;
            this.lstbx_ogretmen.Location = new System.Drawing.Point(15, 155);
            this.lstbx_ogretmen.Name = "lstbx_ogretmen";
            this.lstbx_ogretmen.Size = new System.Drawing.Size(814, 142);
            this.lstbx_ogretmen.TabIndex = 1;
            this.lstbx_ogretmen.UseCompatibleStateImageBehavior = false;
            this.lstbx_ogretmen.SelectedIndexChanged += new System.EventHandler(this.lstbx_ogretmen_SelectedIndexChanged);
            // 
            // btn_ekleteach
            // 
            this.btn_ekleteach.Location = new System.Drawing.Point(98, 466);
            this.btn_ekleteach.Name = "btn_ekleteach";
            this.btn_ekleteach.Size = new System.Drawing.Size(204, 83);
            this.btn_ekleteach.TabIndex = 2;
            this.btn_ekleteach.Text = "ekle";
            this.btn_ekleteach.UseVisualStyleBackColor = true;
            this.btn_ekleteach.Click += new System.EventHandler(this.btn_ekleteach_Click);
            // 
            // btn_silteach
            // 
            this.btn_silteach.Enabled = false;
            this.btn_silteach.Location = new System.Drawing.Point(601, 466);
            this.btn_silteach.Name = "btn_silteach";
            this.btn_silteach.Size = new System.Drawing.Size(178, 83);
            this.btn_silteach.TabIndex = 3;
            this.btn_silteach.Text = "sil";
            this.btn_silteach.UseVisualStyleBackColor = true;
            this.btn_silteach.Click += new System.EventHandler(this.btn_silteach_Click);
            // 
            // btn_guncelleteach
            // 
            this.btn_guncelleteach.Enabled = false;
            this.btn_guncelleteach.Location = new System.Drawing.Point(345, 466);
            this.btn_guncelleteach.Name = "btn_guncelleteach";
            this.btn_guncelleteach.Size = new System.Drawing.Size(188, 83);
            this.btn_guncelleteach.TabIndex = 4;
            this.btn_guncelleteach.Text = "guncelle";
            this.btn_guncelleteach.UseVisualStyleBackColor = true;
            this.btn_guncelleteach.Click += new System.EventHandler(this.btn_guncelleteach_Click);
            // 
            // txtbx_noteach
            // 
            this.txtbx_noteach.Enabled = false;
            this.txtbx_noteach.Location = new System.Drawing.Point(132, 320);
            this.txtbx_noteach.Name = "txtbx_noteach";
            this.txtbx_noteach.Size = new System.Drawing.Size(185, 22);
            this.txtbx_noteach.TabIndex = 5;
            // 
            // txtbx_adteach
            // 
            this.txtbx_adteach.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbx_adteach.Location = new System.Drawing.Point(132, 365);
            this.txtbx_adteach.Name = "txtbx_adteach";
            this.txtbx_adteach.Size = new System.Drawing.Size(185, 22);
            this.txtbx_adteach.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 323);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "ogretmen no";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 368);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "ogretmen ad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 409);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "ogretmen soyad";
            // 
            // txtbx_soyadteach
            // 
            this.txtbx_soyadteach.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbx_soyadteach.Location = new System.Drawing.Point(132, 409);
            this.txtbx_soyadteach.Name = "txtbx_soyadteach";
            this.txtbx_soyadteach.Size = new System.Drawing.Size(185, 22);
            this.txtbx_soyadteach.TabIndex = 10;
            // 
            // cmb_bolum
            // 
            this.cmb_bolum.FormattingEnabled = true;
            this.cmb_bolum.Location = new System.Drawing.Point(405, 320);
            this.cmb_bolum.Name = "cmb_bolum";
            this.cmb_bolum.Size = new System.Drawing.Size(202, 24);
            this.cmb_bolum.TabIndex = 11;
            // 
            // txtbx_araogrno
            // 
            this.txtbx_araogrno.Location = new System.Drawing.Point(132, 34);
            this.txtbx_araogrno.Name = "txtbx_araogrno";
            this.txtbx_araogrno.Size = new System.Drawing.Size(185, 22);
            this.txtbx_araogrno.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "ogretmen no";
            // 
            // txtbx_araograd
            // 
            this.txtbx_araograd.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbx_araograd.Location = new System.Drawing.Point(474, 34);
            this.txtbx_araograd.Name = "txtbx_araograd";
            this.txtbx_araograd.Size = new System.Drawing.Size(148, 22);
            this.txtbx_araograd.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(380, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 17);
            this.label5.TabIndex = 15;
            this.label5.Text = "ogretmen ad";
            // 
            // txtbx_araogrsoyad
            // 
            this.txtbx_araogrsoyad.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbx_araogrsoyad.Location = new System.Drawing.Point(780, 35);
            this.txtbx_araogrsoyad.Name = "txtbx_araogrsoyad";
            this.txtbx_araogrsoyad.Size = new System.Drawing.Size(152, 22);
            this.txtbx_araogrsoyad.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(664, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "ogretmen soyad";
            // 
            // Ogretmen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 561);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtbx_araogrsoyad);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtbx_araograd);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtbx_araogrno);
            this.Controls.Add(this.cmb_bolum);
            this.Controls.Add(this.txtbx_soyadteach);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbx_adteach);
            this.Controls.Add(this.txtbx_noteach);
            this.Controls.Add(this.btn_guncelleteach);
            this.Controls.Add(this.btn_silteach);
            this.Controls.Add(this.btn_ekleteach);
            this.Controls.Add(this.lstbx_ogretmen);
            this.Controls.Add(this.btn_listeleteach);
            this.Name = "Ogretmen";
            this.Text = "Ogretmen";
            this.Load += new System.EventHandler(this.Ogretmen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_listeleteach;
        private System.Windows.Forms.ListView lstbx_ogretmen;
        private System.Windows.Forms.Button btn_ekleteach;
        private System.Windows.Forms.Button btn_silteach;
        private System.Windows.Forms.Button btn_guncelleteach;
        private System.Windows.Forms.TextBox txtbx_noteach;
        private System.Windows.Forms.TextBox txtbx_adteach;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbx_soyadteach;
        private System.Windows.Forms.ComboBox cmb_bolum;
        private System.Windows.Forms.TextBox txtbx_araogrno;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbx_araograd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtbx_araogrsoyad;
        private System.Windows.Forms.Label label6;
    }
}