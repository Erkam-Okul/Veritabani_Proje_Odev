﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;


namespace veritab_onyuz
{
    public partial class Ogretmen : Form
    {
        public Ogretmen()
        {
            InitializeComponent();
        }

        private void btn_listeleteach_Click(object sender, EventArgs e)
        {
            lstbx_ogretmen.Items.Clear();

            lstbx_ogretmen.Columns.Clear();


            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            //var cmd = new NpgsqlCommand("select ogretmen_no,ad,soyad,bolum from ogretmenler", connection);

            string sql = "select o.ogretmen_no,o.ad,o.soyad,o.bolum,b.bolum_adi from ogretmenler o " +
                         "JOin bolumler b on o.bolum = b.bolum_kodu "+
                         "where 1=1 ";

           

            if (!txtbx_araogrno.Text.ToString().Equals(""))
            {
                sql = sql + " and o.ogretmen_no=" + txtbx_araogrno.Text.ToString();
            }


            if (!txtbx_araograd.Text.ToString().Equals(""))
            {
                sql = sql + " and o.ad='" + txtbx_araograd.Text.ToString()+"'";
            }

            if (!txtbx_araogrsoyad.Text.ToString().Equals(""))
            {
                sql = sql + " and o.soyad='" + txtbx_araogrsoyad.Text.ToString() + "'";
            }

            var cmd = new NpgsqlCommand(sql, connection);

            NpgsqlDataReader dr = cmd.ExecuteReader();

            lstbx_ogretmen.View = View.Details;

            lstbx_ogretmen.Columns.Add("Öğretmen No");
            lstbx_ogretmen.Columns.Add("Adı");
            lstbx_ogretmen.Columns.Add("Soyadı");
            lstbx_ogretmen.Columns.Add("Bölum Kodu");
            lstbx_ogretmen.Columns.Add("Bölüm Adı");


            while (dr.Read())
            {
                ///Console.WriteLine(dr[0]+"-"+dr[1]+"-"+dr[2]+"-"+dr[3]);
                lstbx_ogretmen.Items.Add(
                    new ListViewItem(
                       new string[] { dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(),dr[4].ToString()}
                        )
                    );


            }


            connection.Close();



        }

        private void btn_guncelleteach_Click(object sender, EventArgs e)
        {

            if (!kayitKontrol())
            {
                return;
            };

            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            using (var cmd = new NpgsqlCommand("guncelle_ogretmen", connection))

            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_ogretmen_no", Int32.Parse(txtbx_noteach.Text));
                cmd.Parameters.AddWithValue("p_ogretmen_ad", txtbx_adteach.Text);
                cmd.Parameters.AddWithValue("p_ogretmen_soyad", txtbx_soyadteach.Text);
                string[] bolStrArr = cmb_bolum.SelectedItem.ToString().Split('-');

                cmd.Parameters.AddWithValue("p_ogretmen_bolum", bolStrArr[0]);
               

                using (var reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("vt fonk cagrildi.....");
                }
            }

            connection.Close();

            MessageBox.Show("Ogretmen güncellendi");

            btn_listeleteach_Click(sender, e);
        }

        private void btn_silteach_Click(object sender, EventArgs e)
        {
            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            using (var cmd = new NpgsqlCommand("delete_ogretmen", connection))

            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_ogretmen_no", Int32.Parse(txtbx_noteach.Text));


                using (var reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("vt fonk cagrildi.....");
                }
            }

            connection.Close();

            MessageBox.Show("Ogretmen silindi");

            btn_listeleteach_Click(sender, e);

        }

        private void btn_ekleteach_Click(object sender, EventArgs e)
        {

            if (!kayitKontrol())
            {
                return;
            };

            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            using (var cmd = new NpgsqlCommand("ekle_ogretmen", connection))

            {
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.AddWithValue("p_ogretmen_no", Int32.Parse(txtbx_noteach.Text));
                cmd.Parameters.AddWithValue("p_ogretmen_ad", txtbx_adteach.Text);
                cmd.Parameters.AddWithValue("p_ogretmen_soyad", txtbx_soyadteach.Text);
                string[] bolStrArr = cmb_bolum.SelectedItem.ToString().Split('-');

                cmd.Parameters.AddWithValue("p_ogretmen_bolum", bolStrArr[0]);
                

                using (var reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("vt fonk cagrildi.....");
                }
            }

            connection.Close();

            MessageBox.Show("Ogretmen Kaydedildi");

        }

        private Boolean kayitKontrol()
        {
            if (txtbx_adteach.Text.ToString().Equals(""))
            {
                MessageBox.Show("Öğretmen Adı Zorunludur");
                return false;
            }
            if (txtbx_soyadteach.Text.ToString().Equals(""))
            {
                MessageBox.Show("Öğretmen Soyadı Zorunludur");
                return false;
            }

            if (cmb_bolum.SelectedItem == null)
            {
                MessageBox.Show("Bölüm Seçiniz");
                return false;
            }

            return true;
        }
        private void lstbx_ogretmen_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstbx_ogretmen.SelectedIndices.Count <= 0)
            {
                return;
            }

            btn_guncelleteach.Enabled = true;
            btn_silteach.Enabled = true;

            string curItem = lstbx_ogretmen.SelectedItems[0].Text;//.SelectedItems.ToString();
            //Console.WriteLine("secilen:"+ curItem);

            var item = lstbx_ogretmen.SelectedItems[0];

            txtbx_noteach.Text = item.SubItems[0].Text;
            txtbx_adteach.Text = item.SubItems[1].Text;
            txtbx_soyadteach.Text = item.SubItems[2].Text;
            string test = item.SubItems[3].Text;
            cmb_bolum.SelectedIndex = cmb_bolum.FindString(item.SubItems[3].Text);

        }

        private void Ogretmen_Load(object sender, EventArgs e)
        {

            cmb_bolum.Items.Clear();


            var cs = "Host=localhost;Username=postgres;Password=eko12;Database=okul_db";
            var connection = new NpgsqlConnection(cs);
            connection.Open();

            var cmd = new NpgsqlCommand("select bolum_kodu,bolum_adi from bolumler", connection);
            NpgsqlDataReader dr = cmd.ExecuteReader();

          
            while (dr.Read())
            {
                cmb_bolum.Items.Add(dr[0].ToString() + "-" + dr[1].ToString());
            }


            connection.Close();
        }
    }
}
