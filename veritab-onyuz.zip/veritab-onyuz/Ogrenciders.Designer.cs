﻿namespace veritab_onyuz
{
    partial class Ogrenciders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtbx_ogrno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lst_ogrders = new System.Windows.Forms.ListView();
            this.btn_listele = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtbx_ogrno
            // 
            this.txtbx_ogrno.Location = new System.Drawing.Point(239, 48);
            this.txtbx_ogrno.Name = "txtbx_ogrno";
            this.txtbx_ogrno.Size = new System.Drawing.Size(100, 22);
            this.txtbx_ogrno.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(157, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "ogrenci no";
            // 
            // lst_ogrders
            // 
            this.lst_ogrders.HideSelection = false;
            this.lst_ogrders.Location = new System.Drawing.Point(35, 128);
            this.lst_ogrders.Name = "lst_ogrders";
            this.lst_ogrders.Size = new System.Drawing.Size(1268, 307);
            this.lst_ogrders.TabIndex = 2;
            this.lst_ogrders.UseCompatibleStateImageBehavior = false;
            // 
            // btn_listele
            // 
            this.btn_listele.Location = new System.Drawing.Point(472, 31);
            this.btn_listele.Name = "btn_listele";
            this.btn_listele.Size = new System.Drawing.Size(281, 56);
            this.btn_listele.TabIndex = 3;
            this.btn_listele.Text = "listele";
            this.btn_listele.UseVisualStyleBackColor = true;
            this.btn_listele.Click += new System.EventHandler(this.btn_listele_Click);
            // 
            // Ogrenciders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1354, 502);
            this.Controls.Add(this.btn_listele);
            this.Controls.Add(this.lst_ogrders);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbx_ogrno);
            this.Name = "Ogrenciders";
            this.Text = "Ogrenciders";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbx_ogrno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lst_ogrders;
        private System.Windows.Forms.Button btn_listele;
    }
}