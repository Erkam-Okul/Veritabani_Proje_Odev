﻿namespace veritab_onyuz
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_menuogr = new System.Windows.Forms.Button();
            this.btn_menuteach = new System.Windows.Forms.Button();
            this.btn_ogrdersler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_menuogr
            // 
            this.btn_menuogr.Location = new System.Drawing.Point(561, 172);
            this.btn_menuogr.Name = "btn_menuogr";
            this.btn_menuogr.Size = new System.Drawing.Size(167, 72);
            this.btn_menuogr.TabIndex = 0;
            this.btn_menuogr.Text = "ogrenci işleri";
            this.btn_menuogr.UseVisualStyleBackColor = true;
            this.btn_menuogr.Click += new System.EventHandler(this.btn_menuogr_Click);
            // 
            // btn_menuteach
            // 
            this.btn_menuteach.Location = new System.Drawing.Point(172, 172);
            this.btn_menuteach.Name = "btn_menuteach";
            this.btn_menuteach.Size = new System.Drawing.Size(180, 72);
            this.btn_menuteach.TabIndex = 1;
            this.btn_menuteach.Text = "ogrentmen işlemleri";
            this.btn_menuteach.UseVisualStyleBackColor = true;
            this.btn_menuteach.Click += new System.EventHandler(this.btn_menuteach_Click);
            // 
            // btn_ogrdersler
            // 
            this.btn_ogrdersler.Location = new System.Drawing.Point(350, 320);
            this.btn_ogrdersler.Name = "btn_ogrdersler";
            this.btn_ogrdersler.Size = new System.Drawing.Size(192, 67);
            this.btn_ogrdersler.TabIndex = 2;
            this.btn_ogrdersler.Text = "ogrenci dersleri";
            this.btn_ogrdersler.UseVisualStyleBackColor = true;
            this.btn_ogrdersler.Click += new System.EventHandler(this.btn_ogrdersler_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 539);
            this.Controls.Add(this.btn_ogrdersler);
            this.Controls.Add(this.btn_menuteach);
            this.Controls.Add(this.btn_menuogr);
            this.Name = "Menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_menuogr;
        private System.Windows.Forms.Button btn_menuteach;
        private System.Windows.Forms.Button btn_ogrdersler;
    }
}